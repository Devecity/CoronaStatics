CoronaStatics
Contributors: DeveCity
donate link: https://devecity.com
Tags: Corona Live Status, Real-Time Corona Reports, Corona Results In Bangladesh, Corona Results BD
Requires at least: 3.0
Tested up to: 5.5.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

CoronaStatics live data about corona virus (covid-19). this plugin will show today and all time corona virus status in the world and bangladesh.

== Description ==

we are fetching real time coronavirus (covid-19) data from json. we are showing accurate results by using awesome server. we are storing the data into our server and showing up that via CoronaStatics plugin. the plugin is most useful for news website. we will upgrade our plugin with more data and features.

==API Links==
Index: https://api.devecity.com/CoronaStatics/
World: https://api.devecity.com/CoronaStatics/world.php
Bangladesh: https://api.devecity.com/CoronaStatics/bangladesh.php

==Shortcode==
*you can use the [bangladesh] for showing bangladesh data into your website posts or pages. and also you can use the shortcode <?php echo do_shortcode('[bangladesh]');?> anywhere you else such as themes file.
*you can use the [world] for showing world data into your website posts or pages. and also you can use the shortcode <?php echo do_shortcode('[world]');?> anywhere you else such as themes file.

==Audience==
our targeted audience is now bangladesh. but we will not stop here. we are starting from here. we will show word wide all data with our updates.

==Contact Us==
if you face any kind of problems, just contact with us.
Email: plugin@devecity.com

Thanks For Using CoronaStatics Bangladesh plugin for your website.
Best Regrad,
DeveCity
website: https://devecity.com